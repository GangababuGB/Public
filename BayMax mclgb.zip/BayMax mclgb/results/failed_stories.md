## happy path 1 (C:\Users\GB\AppData\Local\Temp\tmp17mknf21\58264cab10764403a057baa17bd1244b_conversation_tests.md)
* greet: hello there!
    - utter_greet   <!-- predicted: find_facility_types -->
    - action_listen   <!-- predicted: find_facility_types -->
* mood_great: amazing
    - utter_happy


## happy path 2 (C:\Users\GB\AppData\Local\Temp\tmp17mknf21\58264cab10764403a057baa17bd1244b_conversation_tests.md)
* greet: hello there!
    - utter_greet   <!-- predicted: find_facility_types -->
    - action_listen   <!-- predicted: find_facility_types -->
* mood_great: amazing
    - utter_happy
* goodbye: bye-bye!
    - utter_goodbye


## sad path 1 (C:\Users\GB\AppData\Local\Temp\tmp17mknf21\58264cab10764403a057baa17bd1244b_conversation_tests.md)
* greet: hello
    - utter_greet   <!-- predicted: find_facility_types -->
    - action_listen   <!-- predicted: find_facility_types -->
* mood_unhappy: not good   <!-- predicted: deny: not good -->
    - utter_cheer_up   <!-- predicted: utter_goodbye -->
    - utter_did_that_help
* affirm: yes
    - utter_happy


## sad path 2 (C:\Users\GB\AppData\Local\Temp\tmp17mknf21\58264cab10764403a057baa17bd1244b_conversation_tests.md)
* greet: hello
    - utter_greet   <!-- predicted: find_facility_types -->
    - action_listen   <!-- predicted: find_facility_types -->
* mood_unhappy: not good   <!-- predicted: deny: not good -->
    - utter_cheer_up   <!-- predicted: utter_goodbye -->
    - utter_did_that_help
* deny: not really
    - utter_goodbye


## sad path 3 (C:\Users\GB\AppData\Local\Temp\tmp17mknf21\58264cab10764403a057baa17bd1244b_conversation_tests.md)
* greet: hi
    - utter_greet   <!-- predicted: find_facility_types -->
    - action_listen   <!-- predicted: find_facility_types -->
* mood_unhappy: very terrible
    - utter_cheer_up
    - utter_did_that_help
* deny: no
    - utter_goodbye


